create database AC2_Christian;

create table cliente (
idClient int primary key auto_increment,
NomeCliente varchar(45),
Numero1 char(15),
Numero2 char(15),
CEP int,
Rua varchar(45),
NumCasa int,
fkPlano int
);


create table plano (
idPlano int primary key auto_increment,
QTDgigas int check (QTDgigas >= 0 and QTDgigas <=100),
minutos int,
valores decimal (5,2)
);


create table Empresas (
idEmpresas int primary key auto_increment,
Operadora char(11),
aplicativos varchar(30)
);


